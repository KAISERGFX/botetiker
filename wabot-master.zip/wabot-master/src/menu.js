module.exports = `
Send a picture or video you will get a sticker. Give a caption to use select mode or crop type (optional).

Supported caption:
- circle, keep scale, top, right top, right, right bottom, bottom, left bottom, left, left top, north, northeast, east, southeast, south, southwest, west, northwest, center, centre, entropy, attention.
`;
